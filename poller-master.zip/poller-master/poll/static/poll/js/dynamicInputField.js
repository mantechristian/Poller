$(function()
{
    $(document).on('click', '.btn-add', function(e)
    {
        e.preventDefault();
        
        var controlForm = $('.controls:first'),
            currentEntry = $(this).parents('.entry:first'),
            newEntry = $(currentEntry.clone()).appendTo(controlForm);
        
        console.log(controlForm);
        console.log(newEntry);

        newEntry.find('input').val('');
        controlForm.find('.entry:not(:last) .btn-add')
            .removeClass('btn-add').addClass('btn-remove')
            .removeClass('btn-success').addClass('btn-danger')
            .html('<span class="fa fa-times choice" aria-hidden="true"></span>');
    }).on('click', '.btn-remove', function(e)
    {
		$(this).parents('.entry:first').remove();

		e.preventDefault();
		return false;
	})
});

// $(document).ready(function(){

//     $("#add").click(function(e) {
//         event.preventDefault();
//         $('#fields').append('<div class="input-group entry"><input class="form-control" id="fields[]" name="fields[]" type="text" placeholder="Enter Choice"><span class="input-group-btn">' +
//          '<input type="button" class="btn btn-danger pull-left submit" value="x" id="delete"/></span></div>');
//     });

//     $('body').on('click', '#delete', function(e) {
//         $(this).parent().parent('div').remove();
//     });

// });