# -*- coding: utf-8 -*-

from __future__ import unicode_literals

import datetime

from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
from django.contrib import admin
from django.core.validators import MaxValueValidator, MinValueValidator

class UserProfile(models.Model):
	owner = models.OneToOneField(User, related_name='profile')
	hasVoted = models.BooleanField(default=False)

	def username(self,obj):
		return obj.get_full_name()
	def __unicode__(self):
		return unicode(self.owner.username)

class Question(models.Model):
	owner = models.ForeignKey(User,on_delete=models.CASCADE)
	question_text = models.CharField(max_length=200)
	pub_date = models.DateTimeField(auto_now_add=True)
	expiry_date = models.DateTimeField(auto_now_add=True)
	question_type = models.PositiveSmallIntegerField(default=1, validators=[MaxValueValidator(2),MinValueValidator(1)])
	def __str__(self):
		return self.question_text
	def was_published_recently(self):
		return self.pub_date >= timezone.now() - datetime.timedelta(days=1)

class Choice(models.Model):
	question = models.ForeignKey(Question, on_delete=models.CASCADE)
	choice_text = models.CharField(max_length=200)
	votes = models.IntegerField(default=0)
	def __str__(self):
		return self.choice_text

class QuestionAdmin(admin.ModelAdmin):
    model = Question
    list_display = ['question_text', 'username', ]
    def username(self, obj):
		return obj.owner.username

	# def __unicode__(self):
	# 	return self.owner.username
class ChoiceVotes(object):
    def __init__(self, choice):
        self.choice = choice.choice_text # do whatever
        self.votes = choice.votes # do whatever

class Vote(models.Model):
	voter = models.ForeignKey(User, related_name='voter')
	question = models.ForeignKey(Question, related_name='vote_question')