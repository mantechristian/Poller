# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.contrib import admin
from .models import Question, Choice, QuestionAdmin, UserProfile, Vote

# class QuestionAdmin(admin.ModelAdmin):
# 	model = Question
# 	list_display = ('question_text', 'get_name')
# 	def get_name(self, obj):
# 		return obj.owner.first_name

admin.site.register(Question,QuestionAdmin)
admin.site.register(Choice)
admin.site.register(UserProfile)
admin.site.register(Vote)