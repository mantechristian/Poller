from django.conf.urls import url

from . import views

app_name = 'poll'

urlpatterns = [
	# url(r'^$', views.index, name='index'),
	# url(r'^$', views.index, name='index'),
	url(r'^dashboard/(?P<username>\w+)$', views.dashboard, name='dashboard'),
	url(r'^(?P<question_id>[0-9]+)/$', views.detail, name='detail'),
	url(r'^(?P<question_id>[0-9]+)/results/$', views.results, name='results'),
	url(r'^(?P<question_id>[0-9]+)/vote/$', views.vote, name='vote'),
	url(r'^$', views.sign_in, name='sign_in'),
	url(r'^sign-out/$', views.sign_out, name='sign_out'),
	url(r'^new_poll/$', views.new_poll, name='new_poll'),
	 url(r'^add/$', views.add_poll, name='add_poll')
	# url(r'^membership/details/(?P<member_id>\d+)/'
]