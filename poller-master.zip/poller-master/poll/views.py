# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import get_object_or_404, render
from .models import Question, UserProfile, Choice, Vote
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.urls import reverse
from django.contrib.auth.models import User
from django.http import HttpResponseRedirect, HttpResponse

def index(request):
	# return sign_in(request)
	if request.user.is_authenticated:
		print "hello"
		username = request.user.username
		print username
		# return redirect('/poll/dashboard',username=username)
		return redirect('poll:dashboard',username=username)
	context = {}
	if request.method == 'POST':
		if request.POST.get('request_type') == 'sign_in':
			print "helli"
			print request.POST.get('request_type')
			username = request.POST.get('username')
			password = request.POST.get('password')
			user = authenticate(username=username, password=password)
			if user:
				login(request, user)
				return redirect('/poll')
		if request.POST.get('request_type') == 'sign_up':
			print "sign_up"
			first_name = request.POST.get('first_name')
			last_name = request.POST.get('last_name')
			username = request.POST.get('username')
			password = request.POST.get('password')
			email = request.POST.get('email')
			print first_name," ",last_name
			user = User.objects.create_user(first_name=first_name,last_name=last_name,username=username,
                                 email=email,
                                 password=password)
			userP = UserProfile.objects.create(owner=user)
	return render(request, 'poll/index.html', context=context)

def dashboard(request,username):
	if not request.user.is_authenticated:
		return redirect('index')
	if not request.user.username == username:
		return redirect('poll:dashboard',username=request.user.username)
	print "dashboard"
	user = User.objects.get(username=username)
	# latest_question_list = Question.objects.filter(owner_id=user.id).order_by('-pub_date')[:5]
	latest_question_list = Question.objects.all().order_by('-pub_date')[:5]
	print user.get_full_name()
	context = {
		'latest_question_list' : latest_question_list,
		'full_name' : user.get_full_name()
	}
	return render(request, 'poll/dashboard.html',context)

def detail(request, question_id):
	import json
	question = get_object_or_404(Question, pk=question_id)
	user = UserProfile.objects.get(owner=request.user)

	try:
		vote = Vote.objects.get(voter=request.user, question=question)
		hasVoted = True;
	except (KeyError, Vote.DoesNotExist):
		hasVoted = False;

	choices=[]
	for choice in question.choice_set.all():
		choice_info = {}
		choice_info['name'] = choice.choice_text
		choice_info['votes'] = choice.votes
		choices.append(choice_info)
	choice_list = json.dumps(choices)
  	context = {
  		'question': question,
  		'choices' : choice_list,
  		'user': user,
  		'hasVoted': hasVoted,
  	}
	return render(request, 'poll/detail.html',context)

def results(request, question_id):
	return HttpResponse("You're looking at the results of question %s." %question_id)

def vote(request, question_id):
	if request.method == 'POST':
		question = get_object_or_404(Question, pk=question_id)
		try:
			selected_choice = question.choice_set.get(pk=request.POST['choice'])
		except (KeyError, Choice.DoesNotExist):
			# Redisplay the question voting form.
			return render(request, 'poll/detail.html', {
				'question': question,
				'error_message': "You didn't select a choice.",
				})
		else:
			v = Vote(voter=request.user, question=question)
			v.save()
			selected_choice.votes += 1
			selected_choice.save()
	        # Always return an HttpResponseRedirect after successfully dealing
	        # with POST data. This prevents data from being posted twice if a
	        # user hits the Back button.
	        return HttpResponseRedirect(reverse('poll:detail', args=(question.id,)))

def new_poll(request):
	if request.user.is_authenticated:
		return render(request, 'poll/create.html')
	return redirect('index')

def sign_in(request):
	if request.user.is_authenticated:
		print "hello"
		return redirect('/poll/dashboard')
	context = {}
	if request.method == 'POST':
		print "helli"
		username = request.POST.get('username')
		password = request.POST.get('password')
		user = authenticate(username=username, password=password)
		if user:
			login(request, user)
			return redirect('/poll')
	return render(request, 'poll/index.html', context=context)

def sign_out(request):
    logout(request)
    return redirect('/poll')

def add_poll(request):
	fields = request.POST.getlist('fields[]')
	print len(fields)
	# print fields[0]
	# print fields[1]
	# print fields[2]
	if request.method == 'POST':
		question_text = request.POST.get('pollQuestion')
		q=Question(question_text=question_text, owner=request.user)
		q.save()
		fields = request.POST.getlist('fields[]')
		for index in range(len(fields)):
   			print 'choice :', fields[index]
			q.choice_set.create(choice_text=fields[index], votes=0)
		q.save()
	return redirect('poll:dashboard',username=request.user.username)