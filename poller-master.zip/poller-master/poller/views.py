# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import get_object_or_404, render
from poll.models import Question,UserProfile
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.urls import reverse
from django.contrib.auth.models import User

def index(request):
	# return sign_in(request)
	if request.user.is_authenticated:
		print "hello"
		username = request.user.username
		print username
		# return redirect('/poll/dashboard',username=username)
		return redirect('poll:dashboard',username=username)
	context = {}
	if request.method == 'POST':
		if request.POST.get('request_type') == 'sign_in':
			print "helli"
			print request.POST.get('request_type')
			username = request.POST.get('username')
			password = request.POST.get('password')
			user = authenticate(username=username, password=password)
			if user:
				login(request, user)
				return redirect('/')
		if request.POST.get('request_type') == 'sign_up':
			print "sign_up"
			first_name = request.POST.get('first_name')
			last_name = request.POST.get('last_name')
			username = request.POST.get('username')
			password = request.POST.get('password')
			email = request.POST.get('email')
			print first_name," ",last_name
			user = User.objects.create_user(first_name=first_name,last_name=last_name,username=username,
                                 email=email,
                                 password=password)
			userP = UserProfile.objects.create(owner=user)
	return render(request, 'index.html', context=context)

def profile(request, username):
	user = User.objects.get(username=username)
	latest_question_list = Question.objects.filter(owner_id=user.id).order_by('-pub_date')[:5]
	context = {
		'username' : user.username,
		'latest_question_list' : latest_question_list,
		'full_name' : user.get_full_name()
	}
	return render(request, 'profile.html', context)

def search(request):
	try:
		user = request.POST.get('username')
		u = User.objects.get(username=user)
		latest_question_list = Question.objects.filter(owner=u).order_by('-pub_date')[:5]
		context = {
			'username' : user,
			'latest_question_list' : latest_question_list,
			'full_name' : u.get_full_name()
		}
		return render(request, 'profile.html', context) 
	except:
		return render(request, 'error.html')
def sign_out(request):
    logout(request)
    return redirect('/')

def goto_edit(request, question_id):
	if not request.user.is_authenticated:
		return redirect('index')

	question = get_object_or_404(Question, pk=question_id)
	context = {
		'question': question
	}
	return render(request, 'edit.html', context=context)

def edit_poll(request, question_id):
	if not request.user.is_authenticated:
		return redirect('index')
	
	if request.method == 'POST':
		q = Question.objects.get(pk=question_id)
		q.question_text = request.POST.get('pollQuestion')
		q.save()
		q.choice_set.all().delete()
		fields = request.POST.getlist('fields[]')
		for index in range(len(fields)):
   			print 'choice :', fields[index]
			q.choice_set.create(choice_text=fields[index], votes=0)
		q.save()

	return redirect('poll:dashboard', username=request.user.username)

def delete(request, question_id):
	if request.method == "POST":
		q = Question.objects.get(pk=question_id)
		print q.question_text
		Question.objects.get(pk=question_id).delete()

	return redirect('poll:dashboard', username=request.user.username)