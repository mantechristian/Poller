"""poller URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/1.11/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  url(r'^$', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  url(r'^$', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.conf.urls import url, include
    2. Add a URL to urlpatterns:  url(r'^blog/', include('blog.urls'))
"""
from django.conf.urls import include, url
from django.contrib import admin
from django.conf import settings
from django.conf.urls.static import static

from poller.views import index, sign_out, profile, search, goto_edit, edit_poll, delete

urlpatterns = [
	url(r'^$', index, name='index'),
    url(r'^sign-out/$', sign_out, name='sign_out'),
    url(r'^profile/(?P<username>\w+)/$', profile, name='profile'),
    url(r'^search/$', search, name='search'), 
    url(r'^admin/', admin.site.urls),
    url(r'^poll/', include('poll.urls')),
    url(r'^(?P<question_id>[0-9]+)/edit/$', goto_edit, name='goto_edit'),
    url(r'^(?P<question_id>[0-9]+)/edit_poll/$', edit_poll, name='edit_poll'),
    url(r'^(?P<question_id>[0-9]+)/delete/$', delete, name='delete'),
]
